#!/usr/bin/env python3
import hashlib, json, os, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'; F=ROOT/'tests/fixtures'
sys.path.insert(0,str(S))
from m8_trust_root import ROOT_TRUST_POLICY_SHA256, load_policy, verify_runtime_material
from m8_release_registry import approved_release_payload

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def can(o): return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def run(a,ok=True):
 e=os.environ.copy(); e['PYTHONDONTWRITEBYTECODE']='1'; cp=subprocess.run(a,text=True,capture_output=True,env=e)
 if ok and cp.returncode: raise AssertionError(cp.stdout+cp.stderr)
 if not ok and not cp.returncode: raise AssertionError('EXPECTED_FAIL')
 return cp

def main():
 r=[]
 def T(n,f):
  try:f();r.append((n,'PASS'))
  except Exception as e:r.append((n,'FAIL:'+repr(e)))
 policy=F/'M8_TIMESTAMP_TRUST_POLICY_V1.json'; ca=F/'freetsa_ca.pem'; signer=F/'freetsa_tsa.crt'; tsr=F/'SEAL_1243_R5_AUTHORITY_MASTER.tsr'; master=F/'SEAL_1243_R5_AUTHORITY_MASTER.txt'
 T('PATH_A_GENUINE_POLICY_SHA_MATCHES_ROOT',lambda: None if sha(policy)==ROOT_TRUST_POLICY_SHA256 else (_ for _ in ()).throw(AssertionError()))
 def legacy():
  p=load_policy(policy); assert p['schema']=='M8_TIMESTAMP_TRUST_POLICY_V1'; assert p['ca_sha256']==sha(ca); assert p['signer_sha256']==sha(signer)
 T('GENUINE_1243_TRUST_POLICY_ACCEPTED_BY_V7',legacy)
 T('GENUINE_1243_RUNTIME_CERT_BYTES_MATCH_POLICY',lambda: verify_runtime_material(policy,ca,signer))
 def imprint():
  cp=run(['openssl','ts','-reply','-in',str(tsr),'-text']); chunks=[]
  for x in cp.stdout.splitlines():
   if x.strip().startswith(('0000 -','0010 -')):
    hx=x.split(' - ',1)[1].split('   ',1)[0].replace('-',' ').split()
    chunks.extend(hx)
  assert ''.join(chunks).lower()=='0c68c940410554cd0b44ab7077b2d6b01782bf86505db71b9dab0d5139d74970'
 T('R5_TSR_MESSAGE_IMPRINT_EQUALS_R5_MASTER_SHA',imprint)
 def forged_registry():
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'r.jsonl'; fake='0'*64; e={'schema':'M8_RELEASE_REGISTRY_EVENT_V1','event_type':'RELEASE_APPROVED','event_id':'x','created_at_utc':'2026-09-25T00:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64,'predictive_semantics_changed':False,'acceptance_evidence_sha256':'4'*64,'independent_review_evidence_sha256':'5'*64,'tsa_trust_policy_sha256':fake}}; p.write_bytes(can(e)+b'\n')
   try: approved_release_payload(p,'R4')
   except RuntimeError as ex: assert 'NON_ROOT_TSA_TRUST_POLICY' in str(ex); return
   raise AssertionError('forged registry accepted')
 T('FORGED_REGISTRY_WITH_NON_ROOT_TRUST_REJECTED',forged_registry)
 def root_release():
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'r.jsonl'; e={'schema':'M8_RELEASE_REGISTRY_EVENT_V1','event_type':'RELEASE_APPROVED','event_id':'x','created_at_utc':'2026-09-25T00:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64,'predictive_semantics_changed':False,'acceptance_evidence_sha256':'4'*64,'independent_review_evidence_sha256':'5'*64,'tsa_trust_policy_sha256':ROOT_TRUST_POLICY_SHA256}}; p.write_bytes(can(e)+b'\n'); assert approved_release_payload(p,'R4')['tsa_trust_policy_sha256']==ROOT_TRUST_POLICY_SHA256
 T('RELEASE_REGISTRY_ACCEPTS_ONLY_FIXED_ROOT_TRUST',root_release)
 T('VERIFY_TRUST_POLICY_CLI_ACCEPTS_LEGACY_PATH_A',lambda: run([sys.executable,str(S/'m8_verify_trust_policy.py'),'--policy',str(policy),'--ca-file',str(ca),'--signer-file',str(signer)]))
 def endpoint_separated():
  p=load_policy(policy); assert p['tsa_url_sha256'] is None
 T('LEGACY_ENDPOINT_IS_OPERATIONAL_NOT_TRUST_ANCHOR',endpoint_separated)
 def no_rotation():
  txt=(S/'m8_trust_root.py').read_text(); assert 'ROOT_TRUST_POLICY_SHA256' in txt and 'rotation' not in txt.lower()
 T('TRUST_ROTATION_NOT_DYNAMICALLY_AUTHORIZED',no_rotation)
 def named_invalid_tsr():
  with tempfile.TemporaryDirectory() as td:
   bad=Path(td)/'bad.tsr'; bad.write_bytes(b'not-a-valid-tsr')
   sys.path.insert(0,str(S)); from m8_schedule import _verify_tsr_data
   try: _verify_tsr_data(master,bad,ca,signer)
   except RuntimeError as ex:
    assert 'TSR_SIGNATURE_INVALID' in str(ex); return
   raise AssertionError('invalid TSR unexpectedly accepted')
 T('INVALID_TSR_HAS_STABLE_ERROR_CODE',named_invalid_tsr)
 def endpoint_doc():
  txt=(ROOT/'12_WEEKLY_TIMESTAMP_OPERATOR_SPEC_R3_2.md').read_text()
  assert 'https://freetsa.org/tsr' in txt and 'not' in txt.lower() and 'trust root' in txt.lower()
 T('FREETSA_ENDPOINT_DOCUMENTED_AS_OPERATIONAL_ONLY',endpoint_doc)
 bad=[x for x in r if x[1]!='PASS']; print(json.dumps({'tests':r,'pass':len(r)-len(bad),'fail':len(bad)},indent=2)); raise SystemExit(1 if bad else 0)
if __name__=='__main__': main()
