#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]; BASES=ROOT/'scripts'

def can(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def run(args,cwd=None,ok=True):
    e=os.environ.copy(); e['PYTHONDONTWRITEBYTECODE']='1'
    cp=subprocess.run(args,cwd=cwd,text=True,capture_output=True,env=e)
    if ok and cp.returncode: raise AssertionError(f'FAIL {args}\n{cp.stdout}\n{cp.stderr}')
    if not ok and cp.returncode==0: raise AssertionError(f'EXPECTED_FAIL {args}\n{cp.stdout}')
    return cp

def write_can(path,obj): Path(path).parent.mkdir(parents=True,exist_ok=True); Path(path).write_bytes(can(obj))
def make_tsa(t):
    run(['openssl','genrsa','-out',str(t/'tsa.key'),'2048'])
    run(['openssl','req','-new','-x509','-key',str(t/'tsa.key'),'-out',str(t/'tsa.crt'),'-days','30','-subj','/CN=M8 Anchor Gate Test TSA','-addext','extendedKeyUsage=critical,timeStamping','-addext','keyUsage=critical,digitalSignature'])
    (t/'tsa.serial').write_text('01\n')
    conf = """[ tsa ]
default_tsa = tsa_config1
[ tsa_config1 ]
serial = {serial}
signer_cert = {cert}
signer_key = {key}
signer_digest = sha256
default_policy = 1.2.3.4.1
digests = sha256
accuracy = secs:1
ordering = yes
tsa_name = yes
ess_cert_id_chain = no
""".format(serial=t/'tsa.serial',cert=t/'tsa.crt',key=t/'tsa.key')
    (t/'tsa.conf').write_text(conf)
def stamp(t,data,tsr):
    Path(tsr).parent.mkdir(parents=True,exist_ok=True); q=Path(str(tsr)+'.tsq')
    run(['openssl','ts','-query','-data',str(data),'-sha256','-cert','-out',str(q)])
    run(['openssl','ts','-reply','-config',str(t/'tsa.conf'),'-section','tsa_config1','-queryfile',str(q),'-out',str(tsr)])
def authority(prev='GENESIS'):
    return {'schema':'M8_ROUND_AUTHORITY_V1','round':1244,'schedule':{'draw_time_kst':'2026-10-03T20:35:00+09:00','cutoff_time_kst':'2026-10-03T20:00:00+09:00','schedule_exception_sha256':None},'release':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64},'prediction_artifacts':[{'role':'PRODUCTION','artifact_sha256':'4'*64,'config_sha256':None}],'scoring_policy_sha256':'5'*64,'prospective_monitors':[],'prev_round_ledger_head_sha256':prev}
def main():
  with tempfile.TemporaryDirectory() as td:
    t=Path(td); (t/'authority').mkdir(); (t/'evidence').mkdir(); (t/'schedule_exceptions').mkdir(); (t/'source').mkdir()
    make_tsa(t)
    policy={'schema':'M8_TSA_TRUST_POLICY_V1','policy_id':'TEST','tsa_url_sha256':sha(b'https://tsa.test'),'ca_pem_sha256':sha((t/'tsa.crt').read_bytes()),'signer_pem_sha256':sha((t/'tsa.crt').read_bytes())}
    write_can(t/'trust.json',policy); trust_sha=sha((t/'trust.json').read_bytes())
    S=t/'scripts'; shutil.copytree(BASES,S)
    rp=S/'m8_trust_root.py'; rp.write_text(rp.read_text().replace('93b1ef5e10156e86e4d93d42f77f509cd271a2683a9ee52a78152a69304b6c6f',trust_sha))
    reg=t/'release_registry.jsonl'
    rev={'schema':'M8_RELEASE_REGISTRY_EVENT_V1','event_type':'RELEASE_APPROVED','event_id':'r4','created_at_utc':'2026-09-25T00:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64,'predictive_semantics_changed':False,'acceptance_evidence_sha256':'6'*64,'independent_review_evidence_sha256':'7'*64,'tsa_trust_policy_sha256':trust_sha}}
    reg.write_bytes(can(rev)+b'\n')
    auth=t/'authority/ROUND_AUTHORITY_1244.json'; write_can(auth,authority())
    tsr=t/'evidence/round_1244/authority.tsr'; stamp(t,auth,tsr)
    led=t/'round_ledger.jsonl'
    run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(led),'--release-registry',str(reg),'--authority',str(auth),'--tsr',str(tsr),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--exception-dir',str(t/'schedule_exceptions')])
    pred=json.loads(led.read_text().splitlines()[0]); pred_hash=sha(can(pred)); reg_hash=sha(can(rev))
    src=t/'source/official_result_1244.txt'; src.write_text('synthetic authenticated official result')
    outcome={'schema':'M8_OUTCOME_AUTH_RECORD_V1','round':1244,'official_draw_time_kst':'2026-10-03T20:35:00+09:00','winning_numbers':[1,2,3,4,5,6],'bonus_number':7,'official_source':{'source_url':'https://official.example/result','artifact_path':'official_result_1244.txt','artifact_sha256':sha(src.read_bytes())}}
    out=t/'outcome.json'; write_can(out,outcome)
    run([sys.executable,str(S/'m8_append_outcome_event.py'),'--ledger',str(led),'--outcome-record',str(out),'--source-root',str(t/'source')])
    base=[sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(led),'--release-registry',str(reg),'--round','1244','--authority-dir',str(t/'authority'),'--evidence-dir',str(t/'evidence'),'--exception-dir',str(t/'schedule_exceptions'),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--outcome-record',str(out),'--outcome-source-root',str(t/'source')]
    cp=run(base); d=json.loads(cp.stdout)
    assert d['confirmatory_factor']==1 and d['eligibility']=='TRACK_ONLY_PUBLIC_ANCHOR_REQUIRED' and d['anchor_reason']=='ANCHOR_LEDGER_ARGUMENT_MISSING',d
    al=t/'anchor_ledger.jsonl'
    ae={'schema':'M8_PUBLIC_ANCHOR_EVENT_V1','sequence':1,'event_type':'PREDRAW_REGISTERED','round':1244,'prev_anchor_event_sha256':'GENESIS','private_repo':'test/private','private_branch':'main','private_commit_sha':'a'*40,'release_registry_head_sha256':reg_hash,'round_ledger_head_sha256':pred_hash,'round_ledger_tail':[{'event_hash':pred_hash,'prev_event_sha256':'GENESIS','event_type':'PREDRAW_REGISTERED','round':1244}],'release_registry_tail':[{'event_hash':reg_hash,'prev_event_sha256':'GENESIS','event_type':'RELEASE_APPROVED','round':None}],'authority_sha256':pred['payload']['authority_sha256'],'authority_tsr_sha256':pred['payload']['tsr_sha256'],'anchor_record_sha256':'8'*64,'anchor_tsr_sha256':'9'*64,'anchor_gentime_utc':'2026-10-03T09:00:00+00:00','confirmatory_anchor_status':'ON_TIME_PUBLIC_ANCHOR'}
    al.write_bytes(can(ae)+b'\n')
    cp2=run(base+['--anchor-ledger',str(al)]); d2=json.loads(cp2.stdout)
    assert d2['eligibility']=='ON_TIME_EVIDENCE_REVERIFIED' and d2['confirmatory_anchor_status']=='ON_TIME_PUBLIC_ANCHOR',d2
    print('PASS_PRIVATE_ONLY_ON_TIME_WITHOUT_ANCHOR_REJECTED_BY_SCORER')
if __name__=='__main__': main()
