#!/usr/bin/env python3
import json, hashlib, os, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'; sys.path.insert(0,str(S))
from m8_public_anchor import can,h,read_anchor_events,build_event,append_event,verify_private_matches_latest,private_head

def write_line(path,obj,append=False):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    mode='ab' if append else 'wb'
    with open(path,mode) as f:f.write(can(obj)+b'\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(a,cwd=None,ok=True):
    e=os.environ.copy();e['PYTHONDONTWRITEBYTECODE']='1';cp=subprocess.run(a,cwd=cwd,text=True,capture_output=True,env=e)
    if ok and cp.returncode: raise AssertionError(cp.stdout+cp.stderr)
    if not ok and not cp.returncode: raise AssertionError('EXPECTED_FAIL')
    return cp

def mk_release(prev='GENESIS',rid='R4'):
 return {'schema':'M8_RELEASE_REGISTRY_EVENT_V1','event_type':'RELEASE_APPROVED','event_id':'r4','created_at_utc':'2026-09-25T00:00:00+00:00','prev_event_sha256':prev,'payload':{'release_id':rid,'whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64,'tsa_trust_policy_sha256':'4'*64}}
def mk_pred(prev='GENESIS',rnd=1244):
 return {'schema':'M8_ROUND_LEDGER_EVENT_V1','event_type':'PREDRAW_REGISTERED','event_id':f'p{rnd}','created_at_utc':'2026-10-03T09:00:00+00:00','prev_event_sha256':prev,'payload':{'round':rnd,'authority_sha256':'5'*64,'timestamp_status':'ON_TIME','tsr_sha256':'6'*64,'tsa_trust_policy_sha256':'4'*64,'gentime_utc':'2026-10-03T09:00:00+00:00'}}
def main():
 results=[]
 def T(n,f):
  try:f();results.append((n,'PASS'))
  except Exception as e:results.append((n,'FAIL:'+repr(e)))
 with tempfile.TemporaryDirectory() as td:
  t=Path(td); private=t/'private'; anchor=t/'anchor'; private.mkdir(); anchor.mkdir()
  reg=private/'release_registry.jsonl'; led=private/'round_ledger.jsonl'; al=anchor/'anchor_ledger.jsonl'
  write_line(reg,mk_release()); led.write_text('')
  record=anchor/'activation.json';record.write_text('{}');tsr=anchor/'activation.tsr';tsr.write_bytes(b'tsr')
  act=build_event(al,reg,led,'soriom1/m8-lotto','main','a'*40,'ACTIVATION',None,record,tsr,'2026-09-25T00:00:00+00:00','ACTIVATION')
  append_event(al,act)
  T('ACTIVATION_ANCHOR_MATCHES_PRIVATE_HEADS',lambda: verify_private_matches_latest(al,reg,led))
  pred=mk_pred();write_line(led,pred)
  pre_record=anchor/'predraw.json';pre_record.write_text('{}');pre_tsr=anchor/'predraw.tsr';pre_tsr.write_bytes(b'tsr2')
  pe=build_event(al,reg,led,'soriom1/m8-lotto','main','b'*40,'PREDRAW_REGISTERED',1244,pre_record,pre_tsr,'2026-10-03T09:00:00+00:00','ON_TIME_PUBLIC_ANCHOR',authority=None,authority_tsr=None)
  append_event(al,pe)
  T('PREDRAW_PUBLIC_ANCHOR_MATCHES_PRIVATE_HEAD',lambda: verify_private_matches_latest(al,reg,led))
  def tailproof():
   e=read_anchor_events(al)[-1]; assert len(e['round_ledger_tail'])==1; assert e['round_ledger_tail'][0]['event_hash']==h(pred); assert e['round_ledger_tail'][0]['prev_event_sha256']=='GENESIS'
  T('PUBLIC_ANCHOR_CARRIES_PRIVATE_LEDGER_EXTENSION_PROOF',tailproof)
  def ledger_delete():
   saved=led.read_bytes();led.write_text('')
   try: verify_private_matches_latest(al,reg,led)
   except RuntimeError as e: assert 'PRIVATE_LEDGER_HEAD_NOT_PUBLICLY_ANCHORED' in str(e)
   else: raise AssertionError('deletion accepted')
   led.write_bytes(saved)
  T('PRIVATE_LEDGER_DELETION_REJECTED',ledger_delete)
  def registry_rewrite():
   saved=reg.read_bytes();x=mk_release();x['payload']['whole19']='9'*64;write_line(reg,x)
   try: verify_private_matches_latest(al,reg,led)
   except RuntimeError as e: assert 'PRIVATE_RELEASE_HEAD_NOT_PUBLICLY_ANCHORED' in str(e)
   else: raise AssertionError('rewrite accepted')
   reg.write_bytes(saved)
  T('PRIVATE_RELEASE_REGISTRY_REWRITE_REJECTED',registry_rewrite)
  def broken_anchor():
   saved=al.read_bytes();lines=al.read_text().splitlines();x=json.loads(lines[-1]);x['prev_anchor_event_sha256']='0'*64;lines[-1]=can(x).decode();al.write_text('\n'.join(lines)+'\n')
   try: read_anchor_events(al)
   except RuntimeError as e: assert 'ANCHOR_CHAIN_AT' in str(e)
   else: raise AssertionError('broken anchor accepted')
   al.write_bytes(saved)
  T('PUBLIC_ANCHOR_CHAIN_BREAK_REJECTED',broken_anchor)
  def conflict():
   rec=anchor/'miss.json';rec.write_text('{}');tr=anchor/'miss.tsr';tr.write_bytes(b'x')
   try: build_event(al,reg,led,'soriom1/m8-lotto','main','c'*40,'ADMIN_MISSED',1244,rec,tr,'2026-10-03T12:00:00+00:00','TRACK_ONLY_LATE_PUBLIC_ANCHOR')
   except RuntimeError as e: assert 'PUBLIC_ANCHOR_ROUND_STATUS_CONFLICT' in str(e);return
   raise AssertionError('conflict accepted')
  T('PREDRAW_CANNOT_LATER_BECOME_ADMIN_MISSED_IN_PUBLIC_ANCHOR',conflict)
  def privacy():
   saved=al.read_bytes();bad=dict(read_anchor_events(al)[-1]);bad['prediction']=[1,2,3,4,5,6];bad['sequence']=3;bad['prev_anchor_event_sha256']=h(read_anchor_events(al)[-1]);
   with al.open('ab') as f:f.write(can(bad)+b'\n')
   try:read_anchor_events(al)
   except RuntimeError as e: assert 'PREDICTIVE_DATA_FORBIDDEN' in str(e)
   else:raise AssertionError('prediction leaked')
   al.write_bytes(saved)
  T('PUBLIC_ANCHOR_FORBIDS_PREDICTION_CONTENT',privacy)
  def fakepass():
   (private/'workflow_status.txt').write_text('PASS')
   saved=led.read_bytes();led.write_text('')
   try:verify_private_matches_latest(al,reg,led)
   except RuntimeError:return
   finally:led.write_bytes(saved)
   raise AssertionError('fake pass overrode public anchor')
  T('FAKE_PRIVATE_WORKFLOW_PASS_CANNOT_OVERRIDE_PUBLIC_ANCHOR',fakepass)
  def git_append_only_good_bad():
   repo=t/'anchorgit';repo.mkdir();run(['git','init','-q'],repo);run(['git','config','user.email','x@y'],repo);run(['git','config','user.name','x'],repo);run(['git','checkout','-qb','anchor'],repo)
   p=repo/'anchor_ledger.jsonl';p.write_bytes(can(act)+b'\n');run(['git','add','.'],repo);run(['git','commit','-qm','a1'],repo)
   p.write_bytes(p.read_bytes()+can(pe)+b'\n');run(['git','add','.'],repo);run(['git','commit','-qm','a2'],repo)
   run([sys.executable,str(S/'m8_verify_anchor_git_history.py'),'--repo',str(repo),'--branch','anchor'])
   p.write_bytes(can(pe)+b'\n');run(['git','add','.'],repo);run(['git','commit','-qm','rewrite'],repo)
   cp=run([sys.executable,str(S/'m8_verify_anchor_git_history.py'),'--repo',str(repo),'--branch','anchor'],ok=False);assert 'NOT_APPEND_ONLY' in cp.stdout+cp.stderr
  T('PUBLIC_ANCHOR_GIT_HISTORY_REWRITE_DETECTED',git_append_only_good_bad)
  def branch_policy_doc():
   d=json.loads((ROOT/'config/public_control_profile.json').read_text()); assert d['control_main_protection']['enforce_admins'];assert d['anchor_branch_protection']['block_force_push'];assert d['anchor_branch_protection']['block_deletion']
  T('FREE_PUBLIC_CONTROL_BRANCH_POLICY_IS_EXPLICIT',branch_policy_doc)
  T('LEGACY_PRIVATE_WEEKLY_WORKFLOW_REMOVED',lambda: None if not (ROOT/'github/workflows/m8-weekly-authority-timestamp.yml').exists() else (_ for _ in ()).throw(AssertionError('legacy private weekly workflow still present')))
  def scorer_gate():
   cp=run([sys.executable,str(ROOT/'tests/test_r3_3_3_anchor_scoring_gate.py')]); assert 'PASS_PRIVATE_ONLY_ON_TIME_WITHOUT_ANCHOR_REJECTED_BY_SCORER' in cp.stdout
  T('PRIVATE_ONLY_ON_TIME_WITHOUT_ANCHOR_REJECTED_BY_SCORER',scorer_gate)
 bad=[x for x in results if x[1]!='PASS'];print(json.dumps({'tests':results,'pass':len(results)-len(bad),'fail':len(bad)},indent=2));raise SystemExit(1 if bad else 0)
if __name__=='__main__':main()
