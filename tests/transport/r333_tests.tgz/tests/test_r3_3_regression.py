#!/usr/bin/env python3
import datetime as dt, hashlib, importlib.util, json, os, subprocess, sys, tempfile, shutil
sys.dont_write_bytecode=True
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'
sys.path.insert(0,str(S))
from m8_finalize_round_status import build_final_event
from m8_schedule import _gentime

def can(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def run(args,cwd=None,ok=True,env=None):
    e=os.environ.copy(); e['PYTHONDONTWRITEBYTECODE']='1'
    if env: e.update(env)
    cp=subprocess.run(args,cwd=cwd,text=True,capture_output=True,env=e)
    if ok and cp.returncode!=0: raise AssertionError(f'FAIL {args}: {cp.returncode}\n{cp.stdout}\n{cp.stderr}')
    if not ok and cp.returncode==0: raise AssertionError(f'EXPECTED_FAIL {args}: {cp.stdout}')
    return cp

def write_can(path,obj): Path(path).parent.mkdir(parents=True,exist_ok=True); Path(path).write_bytes(can(obj))

def authority(cutoff='2026-10-03T20:00:00+09:00',draw='2026-10-03T20:35:00+09:00',exsha=None,prev='GENESIS'):
    return {'schema':'M8_ROUND_AUTHORITY_V1','round':1244,'schedule':{'draw_time_kst':draw,'cutoff_time_kst':cutoff,'schedule_exception_sha256':exsha},'release':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64},'prediction_artifacts':[{'role':'PRODUCTION','artifact_sha256':'4'*64,'config_sha256':None}], 'scoring_policy_sha256':'5'*64,'prospective_monitors':[],'prev_round_ledger_head_sha256':prev}

def make_test_tsa(t):
    run(['openssl','genrsa','-out',str(t/'tsa.key'),'2048'])
    run(['openssl','req','-new','-x509','-key',str(t/'tsa.key'),'-out',str(t/'tsa.crt'),'-days','30','-subj','/CN=M8 Test TSA','-addext','extendedKeyUsage=critical,timeStamping','-addext','keyUsage=critical,digitalSignature'])
    (t/'tsa.serial').write_text('01\n')
    (t/'tsa.conf').write_text(f'''[ tsa ]\ndefault_tsa = tsa_config1\n[ tsa_config1 ]\nserial = {t/'tsa.serial'}\nsigner_cert = {t/'tsa.crt'}\nsigner_key = {t/'tsa.key'}\nsigner_digest = sha256\ndefault_policy = 1.2.3.4.1\ndigests = sha256\naccuracy = secs:1\nordering = yes\ntsa_name = yes\ness_cert_id_chain = no\n''')

def stamp(t,data,tsr):
    Path(tsr).parent.mkdir(parents=True,exist_ok=True)
    tsq=Path(str(tsr)+'.tsq')
    run(['openssl','ts','-query','-data',str(data),'-sha256','-cert','-out',str(tsq)])
    run(['openssl','ts','-reply','-config',str(t/'tsa.conf'),'-section','tsa_config1','-queryfile',str(tsq),'-out',str(tsr)])

def init_git_repo(path):
    run(['git','init','-q'],cwd=path); run(['git','config','user.email','test@example.com'],cwd=path); run(['git','config','user.name','test'],cwd=path)

def main():
  global S
  results=[]
  def T(name,fn):
    try: fn(); results.append((name,'PASS'))
    except Exception as e: results.append((name,'FAIL:'+repr(e)))
  with tempfile.TemporaryDirectory() as td:
    t=Path(td); (t/'authority').mkdir(); (t/'schedule_exceptions').mkdir(); (t/'evidence').mkdir(); (t/'source').mkdir()
    make_test_tsa(t)
    policy={'schema':'M8_TSA_TRUST_POLICY_V1','policy_id':'TEST','tsa_url_sha256':sha(b'https://tsa.test'),'ca_pem_sha256':sha((t/'tsa.crt').read_bytes()),'signer_pem_sha256':sha((t/'tsa.crt').read_bytes())}
    write_can(t/'trust.json',policy); trust_sha=sha((t/'trust.json').read_bytes())
    testS=t/'scripts'; shutil.copytree(S,testS)
    rp=testS/'m8_trust_root.py'; rt=rp.read_text(); rt=rt.replace('93b1ef5e10156e86e4d93d42f77f509cd271a2683a9ee52a78152a69304b6c6f',trust_sha); rp.write_text(rt)
    S=testS

    T('AUTHORITY_CUTOFF_EQUALS_CANONICAL_SCHEDULE',lambda: (run([sys.executable,str(S/'m8_schedule.py'),'--round','1244']).stdout.strip()=='2026-10-03T20:00:00+09:00') or (_ for _ in ()).throw(AssertionError()))
    T('AUTHORITY_DRAW_EQUALS_CANONICAL_SCHEDULE',lambda: (run([sys.executable,str(S/'m8_schedule.py'),'--round','1244','--show-draw-time']).stdout.strip()=='2026-10-03T20:35:00+09:00') or (_ for _ in ()).throw(AssertionError()))

    forged=t/'authority/ROUND_AUTHORITY_1244.json'; write_can(forged,authority('2026-10-10T20:00:00+09:00',draw='2026-10-10T20:35:00+09:00'))
    def t_forged():
        cp=run([sys.executable,str(S/'m8_select_due_authority.py'),'--dir',str(t/'authority'),'--now-utc','2026-10-10T09:00:00+00:00','--window-hours','6'],ok=False)
        assert 'DELAYED_CUTOFF_WITHOUT_SCHEDULE_EXCEPTION' in cp.stderr+cp.stdout
    T('LATE_AUTHORITY_WITH_FORGED_CUTOFF_REJECTED',t_forged)

    notice=t/'schedule_exceptions/notice_1244.txt'; notice.write_text('synthetic postponement')
    ex={'schema':'M8_SCHEDULE_EXCEPTION_V1','round':1244,'default_cutoff_time_kst':'2026-10-03T20:00:00+09:00','default_draw_time_kst':'2026-10-03T20:35:00+09:00','effective_cutoff_time_kst':'2026-10-06T20:00:00+09:00','effective_draw_time_kst':'2026-10-06T20:35:00+09:00','official_notice':{'source_url':'https://official.example/notice','artifact_path':'notice_1244.txt','artifact_sha256':sha(notice.read_bytes())},'timestamp_evidence':{'tsr_path':'SCHEDULE_EXCEPTION_1244.tsr','tsa_trust_policy_sha256':trust_sha}}
    exfile=t/'schedule_exceptions/SCHEDULE_EXCEPTION_1244.json'; write_can(exfile,ex); stamp(t,exfile,t/'schedule_exceptions/SCHEDULE_EXCEPTION_1244.tsr'); exsha=sha(exfile.read_bytes())
    delayed=t/'authority/delayed.json'; write_can(delayed,authority('2026-10-06T20:00:00+09:00','2026-10-06T20:35:00+09:00',exsha))
    def t_ex():
        cp=run([sys.executable,str(S/'m8_schedule.py'),'--authority',str(delayed),'--exception-dir',str(t/'schedule_exceptions'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--trust-policy-sha',trust_sha]); d=json.loads(cp.stdout); assert d['effective_draw_time_kst'].startswith('2026-10-06T20:35:00')
    T('SCHEDULE_EXCEPTION_REQUIRES_PRE_DEFAULT_CUTOFF_TIMESTAMP_AND_DELAYED_DRAW',t_ex)

    # Schema / primary scope / workflow preconditions.
    valid=t/'valid.json'; write_can(valid,authority())
    T('SCHEMA_ENFORCED_IN_WORKFLOW',lambda: run([sys.executable,str(S/'m8_validate_json_schema.py'),'--schema',str(ROOT/'schema/ROUND_AUTHORITY_SCHEMA_V1.json'),'--instance',str(valid)]))
    invalid=t/'invalid.json'; x=authority(); x['prediction_artifacts']=[{'role':'F2_SHADOW','artifact_sha256':'4'*64,'config_sha256':None}]; write_can(invalid,x)
    T('EXACTLY_ONE_PRODUCTION_ARTIFACT_REQUIRED',lambda: run([sys.executable,str(S/'m8_validate_json_schema.py'),'--schema',str(ROOT/'schema/ROUND_AUTHORITY_SCHEMA_V1.json'),'--instance',str(invalid)],ok=False))
    prereg=json.load(open(ROOT/'03_EXTERNAL_REPLICATION_PREREG_V3_DRAFT.json',encoding='utf-8'))
    T('PRIMARY_SCOPE_FIXED',lambda: None if prereg['primary_production_test'].get('data_scope')=='REPLICATION_SET_ONLY' else (_ for _ in ()).throw(AssertionError()))
    T('STRUCTURAL_WARMUP_RULE_FIXED',lambda: None if 'all 45' in prereg['structural_warmup_rule']['definition'] else (_ for _ in ()).throw(AssertionError()))
    T('POWER_CLASSIFICATION_USES_PREREGISTERED_MIE',lambda: None if 'minimum-interest effect' in prereg['secondary_component_family']['power_rule'] else (_ for _ in ()).throw(AssertionError()))

    reg=t/'release_registry.jsonl'; rev={'schema':'M8_RELEASE_REGISTRY_EVENT_V1','event_type':'RELEASE_APPROVED','event_id':'r4','created_at_utc':'2026-09-25T00:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'release_id':'R4','whole19':'1'*64,'method_repro':'2'*64,'selector_anchor':'3'*64,'predictive_semantics_changed':False,'acceptance_evidence_sha256':'6'*64,'independent_review_evidence_sha256':'7'*64,'tsa_trust_policy_sha256':trust_sha}}; reg.write_bytes(can(rev)+b'\n')
    missing_trust=dict(rev); missing_trust['payload']=dict(rev['payload']); missing_trust['payload'].pop('tsa_trust_policy_sha256'); write_can(t/'release_approved_missing_trust.json',missing_trust)
    T('APPROVED_RELEASE_IDENTITY_MATCH_ACCEPTED',lambda: run([sys.executable,str(S/'m8_verify_release_approved.py'),'--registry',str(reg),'--authority',str(valid)]))

    T('RELEASE_APPROVED_REQUIRES_TSA_TRUST_ANCHOR',lambda: run([sys.executable,str(S/'m8_validate_json_schema.py'),'--schema',str(ROOT/'schema/RELEASE_REGISTRY_EVENT_SCHEMA_V1.json'),'--instance',str(t/'release_approved_missing_trust.json')],ok=False))
    badreg=t/'badreg.jsonl'; badreg.write_text('')
    T('UNAPPROVED_RELEASE_REJECTED',lambda: run([sys.executable,str(S/'m8_verify_release_approved.py'),'--registry',str(badreg),'--authority',str(valid)],ok=False))

    # Valid ON_TIME append must independently verify raw evidence.
    auth=t/'authority/ROUND_AUTHORITY_1244.json'; write_can(auth,authority()); tsr=t/'evidence/round_1244/authority.tsr'; stamp(t,auth,tsr); ledger=t/'ledger.jsonl'
    def t_append_valid():
        run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(ledger),'--release-registry',str(reg),'--authority',str(auth),'--tsr',str(tsr),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--exception-dir',str(t/'schedule_exceptions')]); e=json.loads(ledger.read_text().splitlines()[0]); assert e['payload']['timestamp_status']=='ON_TIME'
    T('PREDRAW_APPEND_REVERIFIES_ON_TIME_EVIDENCE',t_append_valid)
    badtsr=t/'bad.tsr'; badtsr.write_bytes(b'not a tsr'); ledger_bad=t/'ledger_bad.jsonl'
    T('FORGED_TSR_CANNOT_CREATE_ON_TIME_EVENT',lambda: run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(ledger_bad),'--release-registry',str(reg),'--authority',str(auth),'--tsr',str(badtsr),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt')],ok=False))

    # ADMIN_MISSED is terminal vs PREDRAW, and CLI cannot accept synthetic future clock.
    admin=t/'admin.jsonl'; admin_ev={'schema':'M8_ROUND_LEDGER_EVENT_V1','event_type':'ADMIN_MISSED','event_id':'admin-missed-1244','created_at_utc':'2026-10-03T12:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'round':1244,'confirmatory_factor':1,'reason':'NO_AUTHORITY_FILE_PRESENT_AND_NEVER_COMMITTED'}}; admin.write_bytes(can(admin_ev)+b'\n')
    T('ADMIN_MISSED_AND_PREDRAW_MUTUALLY_EXCLUSIVE',lambda: run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(admin),'--release-registry',str(reg),'--authority',str(auth),'--tsr',str(tsr),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt')],ok=False))
    T('FINALIZE_CLI_HAS_NO_OPERATOR_NOW_OVERRIDE',lambda: run([sys.executable,str(S/'m8_finalize_round_status.py'),'--ledger',str(t/'z.jsonl'),'--round','1244','--now-utc','2099-01-01T00:00:00Z'],ok=False))

    # build_final_event synthetic-time unit test: existing auth -> TRACK_ONLY, absent -> ADMIN_MISSED.
    repo=t/'repo'; repo.mkdir(); init_git_repo(repo); (repo/'authority').mkdir(); emptyledger=repo/'round_ledger.jsonl'
    def t_track():
        write_can(repo/'authority/ROUND_AUTHORITY_1244.json',authority()); e=build_final_event(emptyledger,repo/'authority',1244,dt.datetime(2026,10,3,12,0,tzinfo=dt.timezone.utc),repo_root=repo); assert e['event_type']=='PREDRAW_REGISTERED' and e['payload']['timestamp_status']=='TRACK_ONLY'; (repo/'authority/ROUND_AUTHORITY_1244.json').unlink()
    T('EXISTING_AUTHORITY_CANNOT_BE_ADMIN_MISSED',t_track)
    T('ADMIN_MISSED_ONLY_WHEN_AUTHORITY_ABSENT',lambda: None if build_final_event(emptyledger,repo/'authority',1244,dt.datetime(2026,10,3,12,0,tzinfo=dt.timezone.utc),repo_root=repo)['event_type']=='ADMIN_MISSED' else (_ for _ in ()).throw(AssertionError()))

    # Deleted committed Authority cannot become ADMIN_MISSED.
    write_can(repo/'authority/ROUND_AUTHORITY_1244.json',authority()); run(['git','add','.'],cwd=repo); run(['git','commit','-qm','authority'],cwd=repo); (repo/'authority/ROUND_AUTHORITY_1244.json').unlink()
    def t_delete():
        try: build_final_event(emptyledger,repo/'authority',1244,dt.datetime(2026,10,3,12,0,tzinfo=dt.timezone.utc),repo_root=repo)
        except RuntimeError as e: assert 'AUTHORITY_DELETION_INTEGRITY_FAILURE' in str(e); return
        raise AssertionError('deletion bypass accepted')
    T('COMMITTED_AUTHORITY_DELETION_CANNOT_ENABLE_ADMIN_MISSED',t_delete)

    # Outcome record + ledger event.
    src=t/'source/official_result_1244.txt'; src.write_text('synthetic authenticated official result')
    outcome={'schema':'M8_OUTCOME_AUTH_RECORD_V1','round':1244,'official_draw_time_kst':'2026-10-03T20:35:00+09:00','winning_numbers':[1,2,3,4,5,6],'bonus_number':7,'official_source':{'source_url':'https://official.example/result','artifact_path':'official_result_1244.txt','artifact_sha256':sha(src.read_bytes())}}
    outcome_path=t/'outcome.json'; write_can(outcome_path,outcome)
    def append_outcome(led): run([sys.executable,str(S/'m8_append_outcome_event.py'),'--ledger',str(led),'--outcome-record',str(outcome_path),'--source-root',str(t/'source')])
    append_outcome(ledger)

    # Synthetic protected-public anchor covering the exact PREDRAW event.
    pred_event=json.loads(ledger.read_text().splitlines()[0]); pred_hash=sha(can(pred_event))
    reg_hash=sha(can(rev)); anchor_ledger=t/'anchor_ledger.jsonl'
    anchor_event={'schema':'M8_PUBLIC_ANCHOR_EVENT_V1','sequence':1,'event_type':'PREDRAW_REGISTERED','round':1244,
      'prev_anchor_event_sha256':'GENESIS','private_repo':'test/private','private_branch':'main','private_commit_sha':'a'*40,
      'release_registry_head_sha256':reg_hash,'round_ledger_head_sha256':pred_hash,
      'round_ledger_tail':[{'event_hash':pred_hash,'prev_event_sha256':'GENESIS','event_type':'PREDRAW_REGISTERED','round':1244}],
      'release_registry_tail':[{'event_hash':reg_hash,'prev_event_sha256':'GENESIS','event_type':'RELEASE_APPROVED','round':None}],
      'authority_sha256':pred_event['payload']['authority_sha256'],'authority_tsr_sha256':pred_event['payload']['tsr_sha256'],
      'anchor_record_sha256':'8'*64,'anchor_tsr_sha256':'9'*64,'anchor_gentime_utc':'2026-10-03T09:00:00+00:00','confirmatory_anchor_status':'ON_TIME_PUBLIC_ANCHOR'}
    anchor_ledger.write_bytes(can(anchor_event)+b'\n')

    # Scorer re-verifies real evidence and accepts normal schedule only with public anchor.
    def t_score_valid():
        cp=run([sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(ledger),'--anchor-ledger',str(anchor_ledger),'--release-registry',str(reg),'--round','1244','--authority-dir',str(t/'authority'),'--evidence-dir',str(t/'evidence'),'--exception-dir',str(t/'schedule_exceptions'),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--outcome-record',str(outcome_path),'--outcome-source-root',str(t/'source')]); d=json.loads(cp.stdout); assert d['eligibility']=='ON_TIME_EVIDENCE_REVERIFIED' and d['confirmatory_anchor_status']=='ON_TIME_PUBLIC_ANCHOR'
    T('SCORER_REVERIFIES_ON_TIME_EVIDENCE',t_score_valid)

    # BLOCK R3.1 regression: a self-signed TSA is rejected unless its policy SHA is approved in Release Registry.
    alt=t/'alt_tsa'; alt.mkdir(); make_test_tsa(alt)
    alt_policy={'schema':'M8_TSA_TRUST_POLICY_V1','policy_id':'UNAPPROVED_TEST','tsa_url_sha256':sha(b'https://alt.tsa.test'),'ca_pem_sha256':sha((alt/'tsa.crt').read_bytes()),'signer_pem_sha256':sha((alt/'tsa.crt').read_bytes())}
    write_can(alt/'trust.json',alt_policy); alt_tsr=alt/'authority.tsr'; stamp(alt,auth,alt_tsr)
    alt_led=t/'alt_ledger.jsonl'
    T('NON_APPROVED_TSA_REJECTED_AT_APPEND',lambda: run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(alt_led),'--release-registry',str(reg),'--authority',str(auth),'--tsr',str(alt_tsr),'--trust-policy-file',str(alt/'trust.json'),'--ca-file',str(alt/'tsa.crt'),'--signer-file',str(alt/'tsa.crt')],ok=False))
    # Directly craft the old vulnerable ledger shape with the unapproved TSA and verify scoring still rejects it.
    mal=t/'malicious_tsa_case'; (mal/'evidence/round_1244').mkdir(parents=True); (mal/'authority').mkdir();
    write_can(mal/'authority/ROUND_AUTHORITY_1244.json',authority()); (mal/'evidence/round_1244/authority.tsr').write_bytes(alt_tsr.read_bytes())
    alt_trust_sha=sha((alt/'trust.json').read_bytes()); auth_sha=sha(auth.read_bytes()); alt_tsr_sha=sha(alt_tsr.read_bytes()); alt_gt=_gentime(alt_tsr).isoformat()
    mal_pred={'schema':'M8_ROUND_LEDGER_EVENT_V1','event_type':'PREDRAW_REGISTERED','event_id':'malicious-unapproved-tsa','created_at_utc':'2026-10-03T10:00:00+00:00','prev_event_sha256':'GENESIS','payload':{'round':1244,'authority_sha256':auth_sha,'timestamp_status':'ON_TIME','tsr_sha256':alt_tsr_sha,'tsa_trust_policy_sha256':alt_trust_sha,'gentime_utc':alt_gt}}
    base_out=json.loads(ledger.read_text().splitlines()[1]); base_out['prev_event_sha256']=sha(can(mal_pred)); mal_led=mal/'ledger.jsonl'; mal_led.write_bytes(can(mal_pred)+b'\n'+can(base_out)+b'\n')
    T('NON_APPROVED_TSA_REJECTED_AT_SCORE',lambda: run([sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(mal_led),'--release-registry',str(reg),'--round','1244','--authority-dir',str(mal/'authority'),'--evidence-dir',str(mal/'evidence'),'--trust-policy-file',str(alt/'trust.json'),'--ca-file',str(alt/'tsa.crt'),'--signer-file',str(alt/'tsa.crt'),'--outcome-record',str(outcome_path),'--outcome-source-root',str(t/'source')],ok=False))

    # Tampered ledger evidence metadata cannot fool scorer.
    spoof=t/'spoof.jsonl'; lines=[json.loads(x) for x in ledger.read_text().splitlines()]; lines[0]['payload']['tsr_sha256']='0'*64; lines[1]['prev_event_sha256']=sha(can(lines[0])); spoof.write_bytes(b''.join(can(e)+b'\n' for e in lines))
    T('SCORER_REJECTS_FORGED_LEDGER_EVIDENCE_FIELDS',lambda: run([sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(spoof),'--release-registry',str(reg),'--round','1244','--authority-dir',str(t/'authority'),'--evidence-dir',str(t/'evidence'),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--outcome-record',str(outcome_path),'--outcome-source-root',str(t/'source')],ok=False))

    # C-1: fabricated postponement may register, but authenticated normal draw downgrades factor to 1 + ISSUE.
    fad=t/'fakecase'; (fad/'authority').mkdir(parents=True); (fad/'evidence/round_1244').mkdir(parents=True); (fad/'schedule_exceptions').mkdir();
    fake_notice=fad/'schedule_exceptions/fake.html'; fake_notice.write_text('fabricated')
    fake_ex=dict(ex); fake_ex['official_notice']={'source_url':'https://fake.example/postpone','artifact_path':'fake.html','artifact_sha256':sha(fake_notice.read_bytes())}; fake_ex_file=fad/'schedule_exceptions/SCHEDULE_EXCEPTION_1244.json'; write_can(fake_ex_file,fake_ex); stamp(t,fake_ex_file,fad/'schedule_exceptions/SCHEDULE_EXCEPTION_1244.tsr'); fake_ex_sha=sha(fake_ex_file.read_bytes())
    fake_auth=fad/'authority/ROUND_AUTHORITY_1244.json'; write_can(fake_auth,authority('2026-10-06T20:00:00+09:00','2026-10-06T20:35:00+09:00',fake_ex_sha)); fake_tsr=fad/'evidence/round_1244/authority.tsr'; stamp(t,fake_auth,fake_tsr); fake_led=fad/'ledger.jsonl'
    run([sys.executable,str(S/'m8_append_predraw_event.py'),'--ledger',str(fake_led),'--release-registry',str(reg),'--authority',str(fake_auth),'--tsr',str(fake_tsr),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--exception-dir',str(fad/'schedule_exceptions')])
    append_outcome(fake_led)
    def t_fake_schedule():
        cp=run([sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(fake_led),'--release-registry',str(reg),'--round','1244','--authority-dir',str(fad/'authority'),'--evidence-dir',str(fad/'evidence'),'--exception-dir',str(fad/'schedule_exceptions'),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--outcome-record',str(outcome_path),'--outcome-source-root',str(t/'source')]); d=json.loads(cp.stdout); assert d['confirmatory_factor']==1 and d['eligibility'].startswith('TRACK_ONLY_'); assert any(json.loads(x)['event_type']=='ISSUE_OPENED' for x in fake_led.read_text().splitlines())
    T('FABRICATED_POSTPONEMENT_DOWNGRADED_AT_SCORE',t_fake_schedule)

    # Conflict scorer is fail-closed.
    conflict=t/'conflict.jsonl'; p0=json.loads(ledger.read_text().splitlines()[0]); a2=dict(admin_ev); a2['prev_event_sha256']=sha(can(p0)); out_evt=json.loads(ledger.read_text().splitlines()[1]); out_evt['prev_event_sha256']=sha(can(a2)); conflict.write_bytes(can(p0)+b'\n'+can(a2)+b'\n'+can(out_evt)+b'\n')
    T('SCORER_FAILS_ON_ADMIN_MISSED_PREDRAW_CONFLICT',lambda: run([sys.executable,str(S/'m8_score_eligibility.py'),'--ledger',str(conflict),'--release-registry',str(reg),'--round','1244','--authority-dir',str(t/'authority'),'--evidence-dir',str(t/'evidence'),'--trust-policy-file',str(t/'trust.json'),'--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt'),'--outcome-record',str(outcome_path),'--outcome-source-root',str(t/'source')],ok=False))

    # C-4 corrections: PREDRAW/ADMIN forbidden, OUTCOME allowed.
    pred_sha=sha(can(json.loads(ledger.read_text().splitlines()[0]))); corr=t/'corr.json'; write_can(corr,{'field':'timestamp_status','new':'TRACK_ONLY'})
    T('PREDRAW_AND_ADMIN_MISSED_NOT_CORRECTABLE',lambda: run([sys.executable,str(S/'m8_append_correction_event.py'),'--ledger',str(ledger),'--superseded-event-sha',pred_sha,'--round','1244','--reason','bad','--correction-json',str(corr)],ok=False))
    outcome_evt=json.loads(ledger.read_text().splitlines()[1]); outcome_sha=sha(can(outcome_evt)); corr2=t/'corr2.json'; write_can(corr2,{'field':'bonus_number','new':8})
    T('OUTCOME_CORRECTION_REFERENCES_EXISTING_EVENT_HASH',lambda: run([sys.executable,str(S/'m8_append_correction_event.py'),'--ledger',str(ledger),'--superseded-event-sha',outcome_sha,'--round','1244','--reason','source correction','--correction-json',str(corr2)]))

    # Authority reissue remains restricted to pre-cutoff, unsealed, output-identical authority.
    old=t/'old_auth.json'; new=t/'new_auth.json'; write_can(old,authority()); nx=authority(); nx['supersedes_unsealed_authority_sha256']=sha(old.read_bytes()); write_can(new,nx); empty=t/'empty_ledger.jsonl'; empty.write_text('')
    T('UNSEALED_AUTHORITY_REISSUE_ONLY_BEFORE_CUTOFF_AND_BEFORE_PREDRAW',lambda: run([sys.executable,str(S/'m8_validate_authority_reissue.py'),'--old',str(old),'--new',str(new),'--ledger',str(empty),'--now-utc','2026-10-03T08:00:00+00:00']))

    # Sealed trust policy remains the source of runtime certificate hashes.
    T('TSA_RUNTIME_MATERIAL_MATCHES_SEALED_TRUST_POLICY_FILE',lambda: run([sys.executable,str(S/'m8_verify_trust_policy.py'),'--policy',str(t/'trust.json'),'--tsa-url','https://tsa.test','--ca-file',str(t/'tsa.crt'),'--signer-file',str(t/'tsa.crt')]))

    # R3.3.3: legacy private scheduled PREDRAW workflow must not exist; protected public control owns the weekly path.
    def t_wf():
        assert not (ROOT/'github/workflows/m8-weekly-authority-timestamp.yml').exists()
        wf=(ROOT/'github/workflows/m8-public-control-weekly.yml').read_text()
        for token in ['Checkout protected public control code','Verify public anchor history is append-only','Append PREDRAW to private ledger and push private state','Build and timestamp hash-only public anchor record','Fast-forward append public anchor branch']:
            assert token in wf
        assert 'm8-public-control-weekly' in wf and 'M8_PRIVATE_REPO_PAT' in wf
    T('LEGACY_PRIVATE_WORKFLOW_REMOVED_PUBLIC_CONTROL_OWNS_PREDRAW',t_wf)

    # No bytecode in deliverable tree.
    T('NO_PYC_OR_PYCACHE_IN_REVIEW_PACKET',lambda: None if not list(ROOT.rglob('*.pyc')) and not list(ROOT.rglob('__pycache__')) else (_ for _ in ()).throw(AssertionError()))

  bad=[x for x in results if not x[1].startswith('PASS')]
  print(json.dumps({'tests':results,'pass':len(results)-len(bad),'fail':len(bad)},ensure_ascii=False,indent=2))
  if bad: raise SystemExit(1)
if __name__=='__main__': main()
